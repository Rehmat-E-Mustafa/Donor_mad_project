import 'package:flutter/material.dart';

class ImpactBox extends StatefulWidget {
  const ImpactBox({Key? key}) : super(key: key);

  @override
  _ImpactBoxState createState() => _ImpactBoxState();
}

class _ImpactBoxState extends State<ImpactBox> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Icon(Icons.book),
          Column(
            children: [
              Text('Family fed',style: TextStyle(
                fontWeight: FontWeight.normal,decoration: TextDecoration.none,
                color: Colors.black38,
                fontSize: 20,
              ),),
              Text('2',style: TextStyle(
                fontSize: 18,fontWeight: FontWeight.normal,decoration: TextDecoration.none,color: Colors.black38,
              ),),
            ],
          )
        ],
      ),
    );
  }
}
