import 'package:flutter/material.dart';
import 'package:get_started/pages/heroes.dart';

class BottomNav extends StatefulWidget {
  const BottomNav({Key? key,
  required this.pageName}) : super(key: key);

  final String pageName;
  @override
  _BottomNavState createState() => _BottomNavState();
}

class _BottomNavState extends State<BottomNav> {
  @override

  Widget build(BuildContext context) {
    return Container(
      height: 40,
      decoration: BoxDecoration(
        boxShadow: [BoxShadow(
          color: Colors.grey.withOpacity(0.8),
          spreadRadius: 10,
          blurRadius: 5,
          offset: Offset(0, 7),
        ),
        ],
        color: Colors.white70,
      ),
      child: Padding(
        padding: const EdgeInsets.only(top:5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [

            Container(
                height: 35,
                width: 110,
                decoration:BoxDecoration(
                  color: Colors.teal,
                  borderRadius: BorderRadius.circular(45),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Icon(Icons.home,size: 25,color: Colors.white,),
                    Text('Home',style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                    ),)
                  ],
                )),
            GestureDetector(
                onTap: (){
                  Navigator.push(context,MaterialPageRoute(builder: (context) => const Heroes()),);
                },
                child: Icon(Icons.search,size: 30,color: Colors.teal,)),
            Icon(Icons.clean_hands,size: 30,color: Colors.teal,),
            Icon(Icons.person,size: 30,color: Colors.teal,),
          ],
        ),
      ),
    );
  }
}
